﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data.Common;
using MySql.Data.Types;

namespace MDV_Project2
{
    class Program
    {
        static void Main(string[] args)
        {

            // MySQL Database Connection String
            string cs = @"server=192.168.1.140;userid=dbremoteuser;password=password;database=Calendar;port=8889";

            // Declare a MySQL Connection
            MySqlConnection conn = null;

            Console.WriteLine("What would you like to do?\n\n" +
                "1) See Useful Links\n" +
                "2) See event details\n" +
                "3) Enter new event");
            string userChoice = Console.ReadLine().ToLower();

            switch (userChoice)
            {
                case "1":
                case "see useful links":
                    {
                        GetLinks(conn, cs);
                    }
                    break;
                case "2":
                case "see event details":
                    {
                        GetEvent(conn, cs);
                    }break;
                case "3":
                case "enter new event":
                    {
                        Console.WriteLine("As this is a simulation, we will be adding a Party at Sarah's House to userId 2's events from 2016-08-19 22:18:13 to 2016-08-19 21:14:15");

                        NewEvent(conn, cs, "Party", "2016-08-19 22:18:13", "2016-08-19 21:14:15", "Sarah's House", "2");
                        Console.ReadKey();
                    }
                    break;
            }



        }

        static void GetLinks(MySqlConnection conn, string connSt)
        {
            try
            {
                Console.Clear();
                // Open a connection to MySQL 
                conn = new MySqlConnection(connSt);
                conn.Open();

                // Declare a MySQL Data Reader
                MySqlDataReader rdr = null;

                // Form SQL Statement
                string stm = "SELECT linkName, hyperLink from UsefulLinks";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                // Execute SQL statement and place the returned data into rdr
                rdr = cmd.ExecuteReader();

                if (!rdr.HasRows)
                {
                    Console.WriteLine("Could not connect.");
                }
                else
                {
                    // Loop through rows returned from MySQL
                    while (rdr.Read())
                    {
                        // Reading rows into variables
                        string hypLink = rdr["hyperLink"] as string;
                        string linkName = rdr["linkName"] as string;
                        
                        Console.WriteLine(linkName + " " + hypLink);
                    }
                }

            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
                Console.ReadKey();
            }
        }


        static void GetEvent(MySqlConnection conn, string connSt)
        {
            try
            {
                // Open a connection to MySQL 
                conn = new MySqlConnection(connSt);
                conn.Open();

                // Declare a MySQL Data Reader
                MySqlDataReader rdr = null;

                Console.WriteLine("Which event id would you like to see?");
                string userChoice = Console.ReadLine();

                Console.Clear();

                // Form SQL Statement
                string stm = $"SELECT eventName, eventDateTimeStart, eventDateTimeEnd, eventLocation from userEvents where eventId={userChoice}";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                // Execute SQL statement and place the returned data into rdr
                rdr = cmd.ExecuteReader();

                if (!rdr.HasRows)
                {
                    Console.WriteLine("Could not connect.");
                }
                else
                {
                    // Loop through rows returned from MySQL
                    while (rdr.Read())
                    {
                        // Reading rows out to variables
                        string eventName = rdr["eventName"] as string;
                        string eventLocation = rdr["eventLocation"] as string;
                        DateTime eventDateTimeStart = rdr.GetDateTime("eventDateTimeStart");
                        DateTime eventDateTimeEnd = rdr.GetDateTime("eventDateTimeEnd");
                        
                        Console.WriteLine(eventDateTimeEnd);

                        // Convert MySQL DateTimes to C# DateTime type
                        DateTime eventStart_datetime = Convert.ToDateTime(eventDateTimeStart);
                        DateTime eventEnd_datetime = Convert.ToDateTime(eventDateTimeEnd);
                        
                        //Format DateTime in a string
                        string eventStart_date = eventStart_datetime.ToString("yyyy-M-dd hh:mm:ss");
                        string eventEnd_date = eventEnd_datetime.ToString("yyyy-M-dd hh:mm:ss");

                        Console.WriteLine("Event Name: "+eventName + "\nLocation: " + eventLocation +"\nStart Date and Time: " +eventStart_date+"\nEnd Date and Time: "+eventEnd_date);
                        Console.ReadKey();
                    }
                }

            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }


        //Some other function

        static void NewEvent(MySqlConnection conn, string connSt, string eventName, string eventDateTimeStart, string eventDateTimeEnd, string eventLocation, string userId)
        {
            conn = new MySqlConnection(connSt);
            conn.Open();

                 // Insert a new event

                MySqlDataReader rdr = null;

                // Form SQL Statement
                string stm = "insert into UserEvents (eventName, eventDateTimeStart, eventDateTimeEnd, eventLocation, userId) values (@eventName, @eventDateTimeStart, @eventDateTimeEnd, @eventLocation, @userId) ";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                //string guid = System.Guid.NewGuid().ToString();
                //this.userId = guid;

                // Binding Variables 
                cmd.Parameters.AddWithValue("@eventName", eventName);
                cmd.Parameters.AddWithValue("@eventDateTimeStart", eventDateTimeStart);
                cmd.Parameters.AddWithValue("@eventDateTimeEnd", eventDateTimeEnd);
                cmd.Parameters.AddWithValue("@eventLocation", eventLocation);
                cmd.Parameters.AddWithValue("@userId", userId);

                // Execute SQL statement and place the returned data into rdr
                rdr = cmd.ExecuteReader();
                rdr.Close();
            
            // Close connection to MySQL 
            conn.Close();

            Console.WriteLine("\nEvent Saved ");
        }

    }
}
