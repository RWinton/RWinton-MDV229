﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDV229_Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {


            string[] coffeeBrands = new string[] {"Dunkin Donuts", "Starbucks", "Folgers", "Maxwell House", "Nescafe", "Millstone Coffee", "Jacobs", "Sanka", "Kenco", "Farmers Union", "High Point", "Boss Coffee", "Mr Brown Coffee", "Beat Box", "Moccona", "Senseo", "State House", "Nabob", "Georgia", "Red Circle" };
            bool stillRunning = true;

            while (stillRunning)
            {
                Console.Clear();
                Console.WriteLine("Main Menu\n\n");
                Console.WriteLine("1. Alphabetical");
                Console.WriteLine("2. Reverse alphabetical");
                Console.WriteLine("3. Random");
                Console.WriteLine("4. Disappearing");
                Console.WriteLine("5. Exit");

                Console.WriteLine("\nHow would you like to see the order of coffee brands?");
                string input = Console.ReadLine().ToLower();



                switch (input)
                {
                    case "1":
                    case "alphabetical":
                        {
                            //Sorted alphabetically
                            Array.Sort(coffeeBrands, StringComparer.InvariantCulture);

                            //Printed back to console in order
                            for (int i = 0; i <=19; i++)
                            {
                                Console.WriteLine("{0}.) {1}", i+1, coffeeBrands[i]);
                            }
                            Console.ReadKey();
                        }
                        break;
                    case "2":
                    case "reverse alphabetical":
                        {
                            int counter = 1;
                            
                            //Sorted alphabetically
                            Array.Sort(coffeeBrands, StringComparer.InvariantCulture);
                            
                            //Printed back to console in reverse
                            for (int i = 19; i >= 0; i--)
                            {
                                Console.WriteLine("{0}.) {1}", counter, coffeeBrands[i]);
                                counter++;
                            }
                            Console.ReadKey();
                        }
                        break;
                    case "3":
                    case "random":
                        {
                            Random randomizer = new Random();

                            coffeeBrands = coffeeBrands.OrderBy(x => randomizer.Next()).ToArray();
                            for (int i = 0; i <= 19; i++)
                            {
                                Console.WriteLine("{0}.) {1}", i + 1, coffeeBrands[i]);
                            }
                            Console.ReadKey();
                        }
                        break;
                    case "4":
                    case "disappearing":
                        {
                            List<string> tempList = new List<string>();
                            Random randomNum = new Random();

                            foreach (string item in coffeeBrands)
                            {
                                tempList.Add(item);
                            }

                            while(tempList.Count > 0)
                            { 
                                foreach (string item in tempList)
                                {
                                    Console.Write(item + " ");
                                }
                                Console.WriteLine("\n\n");
                                int randomNumber = randomNum.Next(tempList.Count - 1);
                                tempList.RemoveAt(randomNumber);
                            }

                            Console.ReadKey();
                            


                        }
                        break;
                    case "5":
                    case "exit":
                        {
                            stillRunning = false;
                        }break;
                }
            }


        }
    }
}
