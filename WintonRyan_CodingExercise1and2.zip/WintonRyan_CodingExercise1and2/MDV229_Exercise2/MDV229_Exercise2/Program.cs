﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDV229_Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] hint = new string[] { "It grows in the ground.", "They are a type of legume.", "Its national day is January 6th.", "They have a 6000 year history as a crop grown by man.", "Referred to as the magical fruit in a crude children's rhyme.", "Vegetarians often use these in lieu of meat in burgers.", "One of the earliest food crops ever cultivated.", "Excellent source of vitamin B6 and protein.", "Pinto, Lima, and Farva are types of these." };
            Console.WriteLine("What is the drink coffee made from?");
            string answer = Console.ReadLine().ToLower();
            Random randomizer = new Random();


            while(answer != "bean")
            {
                int randNum = randomizer.Next(hint.Length - 1);
                Console.WriteLine(hint[randNum]);

                answer = Console.ReadLine();
            }
            Console.WriteLine("Congratulations!  You're correct, coffee is made from a bean!");
            
        }
    }
}
