﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDV229_Exercise3
{
    class Student
    {
        protected string _firstName;
        protected string _lastName;
        protected string _course1;
        protected string _course2;
        protected string _course3;
        protected string _course4;
        protected string _course5;
        protected double _grade1;
        protected double _grade2;
        protected double _grade3;
        protected double _grade4;
        protected double _grade5;

        //many getter/setters for all of the Student properties.
        public string FirstName
        {
            get {return _firstName; }
            set {_firstName = value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
        public string Course1
        {
            get { return _course1; }
            set { _course1 = value; }
        }
        public string Course2
        {
            get { return _course2; }
            set { _course2 = value; }
        }
        public string Course3
        {
            get { return _course3; }
            set { _course3 = value; }
        }
        public string Course4
        {
            get { return _course4; }
            set { _course4 = value; }
        }
        public string Course5
        {
            get { return _course5; }
            set { _course5 = value; }
        }
        public double Grade1
        {
            get { return _grade1; }
            set { _grade1 = value; }
        }
        public double Grade2
        {
            get { return _grade2; }
            set { _grade2 = value; }
        }
        public double Grade3
        {
            get { return _grade3; }
            set { _grade3 = value; }
        }
        public double Grade4
        {
            get { return _grade4; }
            set { _grade4 = value; }
        }
        public double Grade5
        {
            get { return _grade5; }
            set { _grade5 = value; }
        }


        public Student()
        {

        }

        public Student(string firstName, string lastName, string course1, string course2, string course3, string course4, string course5, double grade1, double grade2, double grade3, double grade4, double grade5)
        {
            _firstName = firstName;
            _lastName = lastName;
            _course1 = course1;
            _course2 = course2;
            _course3 = course3;
            _course4 = course4;
            _course5 = course5;
            _grade1 = grade1;
            _grade2 = grade2;
            _grade3 = grade3;
            _grade4 = grade4;
            _grade5 = grade5;
        }

    }
    
}
