﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDV229_Exercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            //creating some students
            Student JBrady = new Student("John", "Brady", "Introduction to brewing", "Latte art", "Bean mixing", "Aroma appreciation", "Bean identification", 39.7, 88.6, 100, 55.9, 75.3);
            Student MPrend = new Student("Marissa", "Prendergast", "Introduction to brewing", "Latte art", "Bean mixing", "Aroma appreciation", "Bean identification", 85.4, 33.0, 85, 78, 64);
            Student CGwood = new Student("Clayton", "Greenwood", "Introduction to brewing", "Latte art", "Bean mixing", "Aroma appreciation", "Bean identification", 18, 74, 22, 19, 90);
            Student EFord = new Student("Emily", "Ford", "Introduction to brewing", "Latte art", "Bean mixing", "Aroma appreciation", "Bean identification", 91, 92, 93, 94, 95);
            Student NMarst = new Student("Naomi", "Marsters", "Introduction to brewing", "Latte art", "Bean mixing", "Aroma appreciation", "Bean identification", 88, 86, 84, 83, 82);

            //setting a student object we can work with
            Student currentStudent = new Student();
            currentStudent = null;

            //List of students for ease of iteration later
            List<Student> roster = new List<Student>();
            roster.Add(JBrady);
            roster.Add(MPrend);
            roster.Add(CGwood);
            roster.Add(EFord);
            roster.Add(NMarst);

            //creating variables for letter grade and gpa
            string letterGrade = null;
            double gpa = 0;

            //setting up the menu with a bool to keep it running
            bool menuIsRunning = true;
            while (menuIsRunning)
            {
                Console.Clear();
                Console.WriteLine("Greetings Admin\n\n");

                //if there's a student already selected then it will show up under the welcome
                if (currentStudent == null)
                {
                    Console.WriteLine("No student currently selected.");
                }
                else
                {
                    Console.WriteLine($"Currently selected student: {currentStudent.FirstName} {currentStudent.LastName}\n");
                    letterGrade = GetLetterGrade(currentStudent);
                    gpa = GetGpa(currentStudent);
                }


                //print the menu
                Console.WriteLine("Please select an option\n");
                Console.WriteLine("1.) View student roster");
                Console.WriteLine("2.) Review GPA");
                Console.WriteLine("3.) Edit Student");
                Console.WriteLine("4.) Exit");
                string input = Console.ReadLine().ToLower();

                //switch/case to choose menu options based on user input
                switch (input)
                {
                    case "1":
                    case "view student roster":
                        {
                            Console.Clear();
                            Console.WriteLine("Student roster: \n");
                            //iterating through the student name list to print them to console
                            foreach (Student item in roster)
                            {
                                Console.WriteLine($"- {item.FirstName} {item.LastName}");
                            }

                            //
                            Console.WriteLine("Please select a student.\n");
                            string studentSelection = Console.ReadLine().ToLower();

                            //iterating through the student list to see if the userinput matches it
                                foreach(Student stu in roster)
                                {
                                    if(studentSelection == stu.FirstName.ToLower()+" " + stu.LastName.ToLower())
                                    {
                                        currentStudent = stu;
                                    }
                                }

                        } break;
                    case "2":
                    case "review gpa":
                        {
                            //ensuring there is a student picked first
                            if(currentStudent == null)
                            {
                                Console.WriteLine("Sorry, please select a student from the roster first.");
                            }
                            //printing student's information if there's an active student
                            else
                            {
                                Console.WriteLine($"{currentStudent.FirstName} {currentStudent.LastName}:\n");
                                Console.WriteLine($"{currentStudent.Course1} : {currentStudent.Grade1}");
                                Console.WriteLine($"{currentStudent.Course1} : {currentStudent.Grade2}");
                                Console.WriteLine($"{currentStudent.Course1} : {currentStudent.Grade3}");
                                Console.WriteLine($"{currentStudent.Course1} : {currentStudent.Grade4}");
                                Console.WriteLine($"{currentStudent.Course1} : {currentStudent.Grade5}\n");
                                Console.WriteLine($"GPA: {gpa}");
                                Console.WriteLine($"Letter Grade: {letterGrade}");

                            }
                            Console.ReadKey();
                        }
                        break;
                    case "3":
                    case "edit student":
                        {
                            //ensuring there's an active student chosen
                            if (currentStudent == null)
                            {
                                Console.WriteLine("Sorry, please select a student from the roster first.");
                            }
                            else
                            {
                                //asking user which course to edit
                                Console.Clear();
                                Console.WriteLine($"Which course would you like to edit {currentStudent.FirstName} {currentStudent.LastName}'s final grade?");
                                Console.WriteLine(currentStudent.Course1);
                                Console.WriteLine(currentStudent.Course2);
                                Console.WriteLine(currentStudent.Course3);
                                Console.WriteLine(currentStudent.Course4);
                                Console.WriteLine(currentStudent.Course5);

                                string courseSelection = Console.ReadLine().ToLower();
                                if(courseSelection == currentStudent.Course1.ToLower())
                                {
                                    Console.WriteLine($"{currentStudent.FirstName} {currentStudent.LastName}'s current grade is {currentStudent.Grade1}.\n\n");
                                    double newGrade = Validation.GetDouble("What will you change the grade to?\n");
                                    //changes the grade for the active student 
                                    currentStudent.Grade1 = newGrade;
                                }
                                else if(courseSelection == currentStudent.Course2.ToLower())
                                {
                                    Console.WriteLine($"{currentStudent.FirstName} {currentStudent.LastName}'s current grade is {currentStudent.Grade2}.\n\n");
                                    double newGrade = Validation.GetDouble("What will you change the grade to?\n");
                                    currentStudent.Grade2 = newGrade;
                                }
                                else if (courseSelection == currentStudent.Course3.ToLower())
                                {
                                    Console.WriteLine($"{currentStudent.FirstName} {currentStudent.LastName}'s current grade is {currentStudent.Grade3}.\n\n");
                                    double newGrade = Validation.GetDouble("What will you change the grade to?\n");
                                    currentStudent.Grade3 = newGrade;
                                }
                                else if (courseSelection == currentStudent.Course4.ToLower())
                                {
                                    Console.WriteLine($"{currentStudent.FirstName} {currentStudent.LastName}'s current grade is {currentStudent.Grade4}.\n\n");
                                    double newGrade = Validation.GetDouble("What will you change the grade to?\n");
                                    currentStudent.Grade4 = newGrade;
                                }
                                else if (courseSelection == currentStudent.Course5.ToLower())
                                {
                                    Console.WriteLine($"{currentStudent.FirstName} {currentStudent.LastName}'s current grade is {currentStudent.Grade5}.\n\n");
                                    double newGrade = Validation.GetDouble("What will you change the grade to?\n");
                                    currentStudent.Grade5 = newGrade;
                                }
                                else
                                {
                                    Console.WriteLine("Sorry, that is not a valid course.");
                                }
                                Console.ReadKey();
                            }
                        }
                        break;
                    case "4":
                    case "exit":
                        {
                            menuIsRunning = false;
                        }
                        break;


                }
            }

            //Just a quick does-the-math-for-you GPA making function
            double GetGpa(Student student)
            {
                double GPA = ((student.Grade1 + student.Grade2 + student.Grade3 + student.Grade4 + student.Grade5)/5) /25;

                return GPA;
            }

            //Just a quick does-the-math-for-you Letter grade making function
            string GetLetterGrade(Student student)
            {
                double gradeAvg = (student.Grade1 + student.Grade2 + student.Grade3 + student.Grade4 + student.Grade5) / 5;
                string letter = null;

                if(gradeAvg >= 89.5)
                {
                    letter = "A";
                }else if(gradeAvg >=79.5 && gradeAvg < 89.5)
                {
                    letter = "B";
                }
                else if (gradeAvg >= 72.5 && gradeAvg < 79.5)
                {
                    letter = "C";
                }
                else if (gradeAvg >= 69.5 && gradeAvg < 72.5)
                {
                    letter = "D";
                }
                else if (gradeAvg < 69.5)
                {
                    letter = "F";
                }

                return letter;
            }

        }
    }
}
