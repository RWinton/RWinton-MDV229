﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDV229_Exercise3
{
    class Validation
    {

        static public int GetInt(string message = "Enter an integer: ")
        {
            int validatedInt;
            string input = null;

            do
            {
                Console.WriteLine(message);
                input = Console.ReadLine();
            } while (!(Int32.TryParse(input, out validatedInt)));

            return validatedInt;
        }

        static public int GetInt(int min, int max, string message)
        {
            int validatedInt;
            string input = null;

            do
            {
                Console.WriteLine(message);
                input = Console.ReadLine();
            } while (!(Int32.TryParse(input, out validatedInt) && (validatedInt >= min && validatedInt <= max)));

            return validatedInt;
        }

        static public bool GetBool(string message = "Enter yes or no: ")
        {
            bool answer = false;
            string input = null;

            bool needAValidResponse = true;

            while (needAValidResponse)
            {
                Console.WriteLine(message);
                input = Console.ReadLine().ToLower();

                switch (input)
                {
                    case "yes":
                    case "y":
                    case "true":
                    case "t":
                        {
                            answer = true;
                            needAValidResponse = false;
                        }
                        break;
                    case "f":
                    case "no":
                    case "n":
                    case "false":
                        {
                            needAValidResponse = false;
                        }
                        break;
                }
            }

            return answer;
        }

        static public double GetDouble(string message = "Enter a number: ")
        {
            double validatedDouble;
            string input = null;

            do
            {
                Console.WriteLine(message);
                input = Console.ReadLine();
            } while (!(Double.TryParse(input, out validatedDouble)));

            return validatedDouble;
        }

        static public double GetDouble(int min, int max, string message = "Enter a number: ")
        {
            double validatedDouble;
            string input = null;

            do
            {
                Console.WriteLine(message);
                input = Console.ReadLine();
            } while (!(Double.TryParse(input, out validatedDouble) && (validatedDouble >= min && validatedDouble <= max)));

            return validatedDouble;
        }

    }
}
