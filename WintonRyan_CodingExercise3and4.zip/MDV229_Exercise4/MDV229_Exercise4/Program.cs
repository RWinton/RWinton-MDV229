﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDV229_Exercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Making a list for the colors and adding them to the list.
            List<string> Colors = new List<string>();
            Colors.Add("red");
            Colors.Add("orange");
            Colors.Add("yellow");
            Colors.Add("green");
            Colors.Add("blue");
            Colors.Add("indigo");
            Colors.Add("violet");

            //Making lists for each fact, and then adding facts to the lists.
            List<string> redFacts = new List<string>();
            List<string> orangeFacts = new List<string>();
            List<string> yellowFacts = new List<string>();
            List<string> greenFacts = new List<string>();
            List<string> blueFacts = new List<string>();
            List<string> indigoFacts = new List<string>();
            List<string> violetFacts = new List<string>();
            redFacts.Add("Red is the first color of the rainbow.");
            redFacts.Add("Red is often used to signify cherry and strawberry flavors in candy.");
            redFacts.Add("Red is the color of anger, and passion.");
            orangeFacts.Add("Orange is the color of pumpkins!  SCAAAAAAARRRRRYYYYYYYYY");
            orangeFacts.Add("The color orange was named after the fruit!");
            orangeFacts.Add("Before being named orange, the English referred to it as geoluhread.");
            yellowFacts.Add("Yellow is considered a happy color.");
            yellowFacts.Add("Yellow is also the color of cowardice.");
            yellowFacts.Add("To have a yellow aura means your have energy.");
            greenFacts.Add("To be green is to be jealous.");
            greenFacts.Add("Green is the second most popular favorite color.");
            greenFacts.Add("The color of love, associate with Venus.");
            blueFacts.Add("Blue is the most favorite color of all.");
            blueFacts.Add("Blue is considered a sad color.  To be blue is to be down.");
            blueFacts.Add("Blue symbolizes loyalty.");
            indigoFacts.Add("Indigo is the sixth color of the rainbow.");
            indigoFacts.Add("Indigo is named after indigo dye.");
            indigoFacts.Add("Indigo, if you didn't know, is a color between blue and violet.");
            violetFacts.Add("Violet is the last color in the visible spectrum of light.");
            violetFacts.Add("Violet is associated with royalty.");
            violetFacts.Add("The color Violet's comes from the flower.");


            //created a dictionary to store everything in, and then added the colors and the fact lists to the dictionary
            Dictionary<string, List<string>> ColorAndFacts = new Dictionary<string, List<string>>();

            ColorAndFacts.Add(Colors[0], redFacts);
            ColorAndFacts.Add(Colors[1], orangeFacts);
            ColorAndFacts.Add(Colors[2], yellowFacts);
            ColorAndFacts.Add(Colors[3], greenFacts);
            ColorAndFacts.Add(Colors[4], blueFacts);
            ColorAndFacts.Add(Colors[5], indigoFacts);
            ColorAndFacts.Add(Colors[6], violetFacts);


            //start the menu
            bool menuIsRunning = true;

            while (menuIsRunning = true)
            {
                Console.Clear();

                if (ColorAndFacts.Keys.Count > 0)
                {
                    Console.WriteLine($"What is your favorite color:\n");

                    foreach (string key in ColorAndFacts.Keys)
                    {
                        Console.WriteLine($"{key}");
                    }
                    Console.WriteLine("");

                    //asking for color input
                    string input = Console.ReadLine().ToLower();

                    switch (input)
                    {
                        case "red":
                            {
                                Console.Clear();
                                //if input matches a key, it will print all facts to the console for that key, and then remove it from the dictionary 
                                foreach (string fact in ColorAndFacts["red"])
                                {
                                    Console.WriteLine($"{fact}");
                                }
                                ColorAndFacts.Remove("red");
                                Console.ReadKey();
                            }
                            break;
                        case "orange":
                            {
                                Console.Clear();
                                foreach (string fact in ColorAndFacts["orange"])
                                {
                                    Console.WriteLine($"{fact}");
                                }
                                ColorAndFacts.Remove("orange");

                                Console.ReadKey();
                            }
                            break;
                        case "yellow":
                            {
                                Console.Clear();
                                foreach (string fact in ColorAndFacts["yellow"])
                                {
                                    Console.WriteLine($"{fact}");
                                }
                                ColorAndFacts.Remove("yellow");

                                Console.ReadKey();
                            }
                            break;
                        case "green":
                            {
                                Console.Clear();
                                foreach (string fact in ColorAndFacts["green"])
                                {
                                    Console.WriteLine($"{fact}");
                                }
                                ColorAndFacts.Remove("green");

                                Console.ReadKey();
                            }
                            break;
                        case "blue":
                            {
                                Console.Clear();
                                foreach (string fact in ColorAndFacts["blue"])
                                {
                                    Console.WriteLine($"{fact}");
                                }
                                ColorAndFacts.Remove("blue");

                                Console.ReadKey();
                            }
                            break;
                        case "indigo":
                            {
                                Console.Clear();
                                foreach (string fact in ColorAndFacts["indigo"])
                                {
                                    Console.WriteLine($"{fact}");
                                }
                                ColorAndFacts.Remove("indigo");

                                Console.ReadKey();
                            }
                            break;
                        case "violet":
                            {
                                Console.Clear();
                                foreach (string fact in ColorAndFacts["violet"])
                                {
                                    Console.WriteLine($"{fact}");
                                }
                                ColorAndFacts.Remove("violet");

                                Console.ReadKey();
                            }
                            break;
                    }

                }
                else
                {
                    //once done it tells the user there are no more colors to learn about
                    Console.WriteLine("You have successfully learned about every color!  Go forth and share your newfound knowledge!");
                    Console.ReadKey();
                    menuIsRunning = false;
                }
            }
   
        }
    }
}
