﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WintonRyan_CodingExercise06
{
    class Player
    {
        protected string _playerName;
        protected List<Card> _cardList;
        protected int _cardTotal;

        public string PlayerName { get { return _playerName; } set { _playerName = value; } }
        public List<Card> CardList { get { return _cardList; } set { _cardList = value; } }
        public int CardTotal { get { return _cardTotal; } set{ _cardTotal = value; } }

        public Player()
        {

        }
        public Player(string playerName, List<Card> cardList)
        {
            _playerName = playerName;
            _cardList = cardList;
        }
        public Player(string playerName, List<Card> cardList, int cardTotal)
        {
            _playerName = playerName;
            _cardList = cardList;
            _cardTotal = cardTotal;
        }
    }
}
