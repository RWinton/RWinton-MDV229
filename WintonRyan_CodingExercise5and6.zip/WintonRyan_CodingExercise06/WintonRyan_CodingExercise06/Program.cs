﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WintonRyan_CodingExercise06
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Card> fullDeck = DeckBuilder();
            List<Card> player1 = new List<Card>();
            List<Card> player2 = new List<Card>();
            List<Card> player3 = new List<Card>();
            List<Card> player4 = new List<Card>();

            Console.WriteLine("Let's play a card game!!!");
            Console.ReadKey();


            Console.WriteLine("Please enter Player 1's name:");
            string player1Name = Console.ReadLine();
            Console.WriteLine("Please enter Player 2's name:");
            string player2Name = Console.ReadLine();
            Console.WriteLine("Please enter Player 3's name:");
            string player3Name = Console.ReadLine();
            Console.WriteLine("Please enter Player 4's name:");
            string player4Name = Console.ReadLine();

            Console.Clear();
            Console.WriteLine("I'm shuffling the deck and dealing each player 13 cards.  Winner is the one with the highest point total.");
            Console.ReadKey();
            Console.Clear();


            Player play1 = new Player(player1Name, player1);
            Player play2 = new Player(player2Name, player2);
            Player play3 = new Player(player3Name, player3);
            Player play4 = new Player(player4Name, player4);
            List<Player> PlayerList = new List<Player>();
            PlayerList.Add(play1);
            PlayerList.Add(play2);
            PlayerList.Add(play3);
            PlayerList.Add(play4);

            List<Card> shuffledDeck = new List<Card>();
            Random rand = new Random();
            while (fullDeck.Count > 0)
            {
                int i = rand.Next(0, fullDeck.Count);
                shuffledDeck.Add(fullDeck[i]);
                fullDeck.RemoveAt(i);
            }

            int counter = 51;
            while(counter >= 0)
            {
                play1.CardList.Add(shuffledDeck[counter]);
                counter--;
                play2.CardList.Add(shuffledDeck[counter]);
                counter--;
                play3.CardList.Add(shuffledDeck[counter]);
                counter--;
                play4.CardList.Add(shuffledDeck[counter]);
                counter--;
            }

            int p1total = 0;
            int p2total = 0;
            int p3total = 0;
            int p4total = 0;

            foreach(Card item in play1.CardList)
            {
                p1total = p1total + item.CardValue;
            }
            Player play1a = new Player(play1.PlayerName, play1.CardList, p1total);

            foreach (Card item in play2.CardList)
            {
                p2total = p2total + item.CardValue;
            }
            Player play2a = new Player(play2.PlayerName, play2.CardList, p2total);

            foreach (Card item in play3.CardList)
            {
                p3total = p3total + item.CardValue;
            }
            Player play3a = new Player(play3.PlayerName, play3.CardList, p3total);

            foreach (Card item in play4.CardList)
            {
                p4total = p4total + item.CardValue;
            }
            Player play4a = new Player(play4.PlayerName, play4.CardList, p4total);

            List<Player> PlayerListUpdated = new List<Player>();
            PlayerListUpdated.Add(play1a);
            PlayerListUpdated.Add(play2a);
            PlayerListUpdated.Add(play3a);
            PlayerListUpdated.Add(play4a);

            int deckTotal = (p1total + p2total + p3total + p4total);

            PlayerListUpdated.Sort((x, y) => y.CardTotal.CompareTo(x.CardTotal));
            
            string cardList1 = HandWriter(PlayerListUpdated[0]);
            string cardList2 = HandWriter(PlayerListUpdated[1]);
            string cardList3 = HandWriter(PlayerListUpdated[2]);
            string cardList4 = HandWriter(PlayerListUpdated[3]);

            Console.WriteLine($"Place: Winner");
            Console.WriteLine($"Player Name: {PlayerListUpdated[0].PlayerName}");
            Console.WriteLine($"Cards: {cardList1}");
            Console.WriteLine($"Total Value: {PlayerListUpdated[0].CardTotal}\n\n");

            Console.WriteLine($"Place: Runner-up");
            Console.WriteLine($"Player Name: {PlayerListUpdated[1].PlayerName}");
            Console.WriteLine($"Cards: {cardList2}");
            Console.WriteLine($"Total Value: {PlayerListUpdated[1].CardTotal}\n\n");

            Console.WriteLine($"Place: 3rd");
            Console.WriteLine($"Player Name: {PlayerListUpdated[2].PlayerName}");
            Console.WriteLine($"Cards: {cardList3}");
            Console.WriteLine($"Total Value: {PlayerListUpdated[2].CardTotal}\n\n");

            Console.WriteLine($"Place: LAST");
            Console.WriteLine($"Player Name: {PlayerListUpdated[3].PlayerName}");
            Console.WriteLine($"Cards: {cardList4}");
            Console.WriteLine($"Total Value: {PlayerListUpdated[3].CardTotal}\n\n");


            Console.WriteLine($"Total Deck Value: {deckTotal}");

        }

        static string HandWriter(Player player)
        {
            string playerHand = null;

            foreach(Card card in player.CardList)
            {
                playerHand = playerHand + card.CardName + ", ";
            }

            playerHand.ToString().Trim();

            return playerHand;
        }

        static List<Card> DeckBuilder()
        {
            List<Card> Deck = new List<Card>();

            Card TwoHearts = new Card("2 of Hearts", 2);
            Card ThreeHearts = new Card("3 of Hearts", 3);
            Card FourHearts = new Card("4 of Hearts", 4);
            Card FiveHearts = new Card("5 of Hearts", 5);
            Card SixHearts = new Card("6 of Hearts", 6);
            Card SevenHearts = new Card("7 of Hearts", 7);
            Card EightHearts = new Card("8 of Hearts", 8);
            Card NineHearts = new Card("9 of Hearts", 9);
            Card TenHearts = new Card("10 of Hearts", 10);
            Card JackHearts = new Card("Jack of Hearts", 12);
            Card QueenHearts = new Card("Queen of Hearts", 12);
            Card KingHearts = new Card("King of Hearts", 12);
            Card AceHearts = new Card("Ace of Hearts", 15);

            Card TwoDiamonds = new Card("2 of Diamonds", 2);
            Card ThreeDiamonds = new Card("3 of Diamonds", 3);
            Card FourDiamonds = new Card("4 of Diamonds", 4);
            Card FiveDiamonds = new Card("5 of Diamonds", 5);
            Card SixDiamonds = new Card("6 of Diamonds", 6);
            Card SevenDiamonds = new Card("7 of Diamonds", 7);
            Card EightDiamonds = new Card("8 of Diamonds", 8);
            Card NineDiamonds = new Card("9 of Diamonds", 9);
            Card TenDiamonds = new Card("10 of Diamonds", 10);
            Card JackDiamonds = new Card("Jack of Diamonds", 12);
            Card QueenDiamonds = new Card("Queen of Diamonds", 12);
            Card KingDiamonds = new Card("King of Diamonds", 12);
            Card AceDiamonds = new Card("Ace of Diamonds", 15);

            Card TwoSpades = new Card("2 of Spades", 2);
            Card ThreeSpades = new Card("3 of Spades", 3);
            Card FourSpades = new Card("4 of Spades", 4);
            Card FiveSpades = new Card("5 of Spades", 5);
            Card SixSpades = new Card("6 of Spades", 6);
            Card SevenSpades = new Card("7 of Spades", 7);
            Card EightSpades = new Card("8 of Spades", 8);
            Card NineSpades = new Card("9 of Spades", 9);
            Card TenSpades = new Card("10 of Spades", 10);
            Card JackSpades = new Card("Jack of Spades", 12);
            Card QueenSpades = new Card("Queen of Spades", 12);
            Card KingSpades = new Card("King of Spades", 12);
            Card AceSpades = new Card("Ace of Spades", 15);

            Card TwoClubs = new Card("2 of Clubs", 2);
            Card ThreeClubs = new Card("3 of Clubs", 3);
            Card FourClubs = new Card("4 of Clubs", 4);
            Card FiveClubs = new Card("5 of Clubs", 5);
            Card SixClubs = new Card("6 of Clubs", 6);
            Card SevenClubs = new Card("7 of Clubs", 7);
            Card EightClubs = new Card("8 of Clubs", 8);
            Card NineClubs = new Card("9 of Clubs", 9);
            Card TenClubs = new Card("10 of Clubs", 10);
            Card JackClubs = new Card("Jack of Clubs", 12);
            Card QueenClubs = new Card("Queen of Clubs", 12);
            Card KingClubs = new Card("King of Clubs", 12);
            Card AceClubs = new Card("Ace of Clubs", 15);

            Deck.Add(TwoClubs);
            Deck.Add(ThreeClubs);
            Deck.Add(FourClubs);
            Deck.Add(FiveClubs);
            Deck.Add(SixClubs);
            Deck.Add(SevenClubs);
            Deck.Add(EightClubs);
            Deck.Add(NineClubs);
            Deck.Add(TenClubs);
            Deck.Add(JackClubs);
            Deck.Add(QueenClubs);
            Deck.Add(KingClubs);
            Deck.Add(AceClubs);

            Deck.Add(TwoDiamonds);
            Deck.Add(ThreeDiamonds);
            Deck.Add(FourDiamonds);
            Deck.Add(FiveDiamonds);
            Deck.Add(SixDiamonds);
            Deck.Add(SevenDiamonds);
            Deck.Add(EightDiamonds);
            Deck.Add(NineDiamonds);
            Deck.Add(TenDiamonds);
            Deck.Add(JackDiamonds);
            Deck.Add(QueenDiamonds);
            Deck.Add(KingDiamonds);
            Deck.Add(AceDiamonds);

            Deck.Add(TwoHearts);
            Deck.Add(ThreeHearts);
            Deck.Add(FourHearts);
            Deck.Add(FiveHearts);
            Deck.Add(SixHearts);
            Deck.Add(SevenHearts);
            Deck.Add(EightHearts);
            Deck.Add(NineHearts);
            Deck.Add(TenHearts);
            Deck.Add(JackHearts);
            Deck.Add(QueenHearts);
            Deck.Add(KingHearts);
            Deck.Add(AceHearts);

            Deck.Add(TwoSpades);
            Deck.Add(ThreeSpades);
            Deck.Add(FourSpades);
            Deck.Add(FiveSpades);
            Deck.Add(SixSpades);
            Deck.Add(SevenSpades);
            Deck.Add(EightSpades);
            Deck.Add(NineSpades);
            Deck.Add(TenSpades);
            Deck.Add(JackSpades);
            Deck.Add(QueenSpades);
            Deck.Add(KingSpades);
            Deck.Add(AceSpades);


            return Deck;
        }
    }
}
