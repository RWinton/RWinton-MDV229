﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WintonRyan_CodingExercise06
{
    class Card
    {
        protected string _cardName;
        protected int _cardValue;


        public string CardName { get {return _cardName; } set {_cardName = value; } }
        public int CardValue { get {return _cardValue; } set {_cardValue = value; } }

        public Card(string cardName, int cardValue)
        {
            _cardName = cardName;
            _cardValue = cardValue;
        }

    }
}
