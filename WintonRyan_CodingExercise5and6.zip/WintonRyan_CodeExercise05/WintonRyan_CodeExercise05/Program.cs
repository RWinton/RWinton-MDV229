﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WintonRyan_CodeExercise05
{
    class Program
    {
        static void Main(string[] args)
        {
            int tiedGames = 0;
            int wonGames = 0;
            int lostGames = 0;
            int playTimes = 10;

            while (playTimes > 0)
            {
                Console.Clear();
                Console.WriteLine($"We're here to play ten rounds of the best game ever.\n\nRounds remaining: {playTimes}");
                Console.WriteLine("It is time to play Rock, Paper, Scissors, Lizard, Spock");
                Console.WriteLine("Choose your weapon!");
                string input = Console.ReadLine().ToLower();
                Random rand = new Random();
                int compChoice = rand.Next(5);

                List<string> compOptions = new List<string>();
                compOptions.Add("rock");
                compOptions.Add("paper");
                compOptions.Add("scissors");
                compOptions.Add("lizard");
                compOptions.Add("spock");

                switch (input)
                {
                    case "rock":
                        {
                            if (compOptions[compChoice] == "paper" || compOptions[compChoice] == "spock")
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The computer wins!");
                                lostGames++;
                            }

                            else if ((compOptions[compChoice] == "scissors") || (compOptions[compChoice] == "lizard"))
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("You have triumphed!");
                                wonGames++;
                            }

                            else
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The game has tied");
                                tiedGames++;
                            }

                        }
                        break;
                    case "paper":
                        {

                            if (compOptions[compChoice] == "scissors" || compOptions[compChoice] == "lizard")
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The computer wins!");
                                lostGames++;
                            }

                            else if ((compOptions[compChoice] == "rock") || (compOptions[compChoice] == "spock"))
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("You have triumphed!");
                                wonGames++;
                            }

                            else
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The game has tied");
                                tiedGames++;
                            }

                        }
                        break;
                    case "scissors":
                        {

                            if (compOptions[compChoice] == "rock" || compOptions[compChoice] == "spock")
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The computer wins!");
                                lostGames++;
                            }

                            else if ((compOptions[compChoice] == "paper") || (compOptions[compChoice] == "lizard"))
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("You have triumphed!");
                                wonGames++;
                            }

                            else
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The game has tied");
                                tiedGames++;
                            }

                        }
                        break;
                    case "lizard":
                        {

                            if (compOptions[compChoice] == "rock" || compOptions[compChoice] == "scissors")
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The computer wins!");
                                lostGames++;
                            }

                            else if ((compOptions[compChoice] == "spock") || (compOptions[compChoice] == "paper"))
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("You have triumphed!");
                                wonGames++;
                            }

                            else
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The game has tied");
                                tiedGames++;
                            }

                        }
                        break;
                    case "spock":
                        {

                            if (compOptions[compChoice] == "paper" || compOptions[compChoice] == "lizard")
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The computer wins!");
                                lostGames++;
                            }

                            else if ((compOptions[compChoice] == "scissors") || (compOptions[compChoice] == "rock"))
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("You have triumphed!");
                                wonGames++;
                            }

                            else
                            {
                                Console.WriteLine($"The computer chose: {compOptions[compChoice]}\n");
                                Console.WriteLine("The game has tied");
                                tiedGames++;
                            }

                        }
                        break;
                }

                playTimes--;
                Console.ReadKey();
            }
            Console.Clear();

            Console.WriteLine("10 games have been played!\n\n" +
                $"Player Wins: {wonGames}\n" +
                $"Player losses: {lostGames}\n" +
                $"Tied games: {tiedGames}");

        }
    }
}
