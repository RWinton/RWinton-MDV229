﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WintonRyan_CodeExercise07
{
    class Program
    {
        static void Main(string[] args)
        {
            //count variable to keep track of loops
            int countdown = 12;
            //list to keep madlib choices in
            List<string> madLibChoices = new List<string>();

            Console.WriteLine("Hello, can you help me finish a story?  If so, I will ask you for a series of nouns, adjectives, and verbs.");
            
            string answer = Console.ReadLine().ToLower();
            
            //while loop to ensure they answer yes or no and nothing else
            while(answer != "yes" && answer != "no")
            {
                Console.Clear();
                Console.WriteLine("Please enter an appropriate response.\n\nWill you help write this story?  Yes or no.");
                answer = Console.ReadLine().ToLower();
            }

            //If they answer yes we play the game  If they answered no, the program closes.
            if (answer == "yes")
            {
                while (countdown > 0)
                {
                    //For each different type of word requested we'll ask for a different type
                    if (countdown == 12 || countdown == 8 || countdown == 5 || countdown == 1)
                    {
                        Console.WriteLine("Please enter an adjective (a word which describes an object):");
                        string input = Console.ReadLine().ToLower();
                        madLibChoices.Add(input);
                        countdown--;

                    }
                    else if (countdown == 11 || countdown == 7 || countdown == 6)
                    {
                        Console.WriteLine("Please enter an noun (a person, place, or thing):");
                        string input = Console.ReadLine().ToLower();
                        madLibChoices.Add(input);
                        countdown--;
                    }
                    else if (countdown == 10 || countdown == 2)
                    {
                        Console.WriteLine("Please enter a verb (past tense):");
                        string input = Console.ReadLine().ToLower();
                        madLibChoices.Add(input);
                        countdown--;
                    }
                    else if (countdown == 9 || countdown == 3)
                    {
                        Console.WriteLine("Please enter an adverb (a word which describes an action):");
                        string input = Console.ReadLine().ToLower();
                        madLibChoices.Add(input);
                        countdown--;
                    }
                    else if (countdown == 4)
                    {
                        Console.WriteLine("Please enter a verb (an action):");
                        string input = Console.ReadLine().ToLower();
                        madLibChoices.Add(input);
                        countdown--;
                    }
                }

                //Print off of the entire story
                Console.Write($"Today I went to the zoo.  I saw a ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{madLibChoices[0]} {madLibChoices[1]} ");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write("jumping up and down in its tree. He ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{madLibChoices[2]} {madLibChoices[3]} ");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write($"through the large tunnel that led to its ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{madLibChoices[4]} {madLibChoices[5]}");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write(".  I got some peanuts and passed them through the cage to a gigantic gray ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{ madLibChoices[6]} ");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write("towering above my head. Feeding that animal made me hungry.  I went to get a ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{madLibChoices[7]}");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write(" scoop of ice cream.  It filled my stomach.  Afterwards I had to ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{madLibChoices[8]} {madLibChoices[9]} ");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write("to catch our bus.  When I got home I ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{madLibChoices[10]} ");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write("my mom for a ");
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write($"{ madLibChoices[11]} ");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write("day at the zoo.");
            }


        }
    }
}
